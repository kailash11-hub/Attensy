# Exported Vite + React Project

## Requirements

- **Node.js** version `>=18.0.0` recommended

## Getting Started

1. Install dependencies:

```bash
npm install
```

2. Start the development server:

```bash
npm run dev
```

3. Build for production:

```bash
npm run build
```

4. Preview the production build locally:

```bash
npm run preview
```

This is a Vite + React project scaffold exported from your builder.