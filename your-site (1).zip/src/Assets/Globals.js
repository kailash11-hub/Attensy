export const tenantId = 7523;
        export const workflowConfigId = 7170