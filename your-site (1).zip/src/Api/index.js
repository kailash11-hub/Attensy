import * as tenantAppAPI from "./tenantApp";

export { tenantAppAPI };