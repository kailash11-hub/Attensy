import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';



const AppRoutes = () => {
  return (
  <BrowserRouter>
    <Switch>

    </Switch>
  </BrowserRouter>
  );
};

export default AppRoutes;