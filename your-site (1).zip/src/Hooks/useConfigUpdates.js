import { useSelector } from 'react-redux';

export const getConfigUpdates = (id) => {
    const configUpdates = useSelector(state => state.configUpdates.updates);
    return configUpdates.get(id);
};